from dactim_mri.sorting import sort_dicom
from dactim_mri.conversion import convert_dicom_to_nifti

convert_dicom_to_nifti(r"C:\Users\467355\Desktop\data\rachis\SPINE^PRISMATICS\^\20230424\6 T2_SPACE_SAG_P2_ISO_0.7MM", r"C:\Users\467355\Desktop\data\rachis")


